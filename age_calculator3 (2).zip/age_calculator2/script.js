const dayInput = document.getElementById("day");
const monthInput = document.getElementById("month");
const yearInput = document.getElementById("year");
const monthSpan = document.querySelector(".output-month");
const yearSpan = document.querySelector(".output-year");
const daySpan = document.querySelector(".output-day");

const yearErrorSpan = document.querySelector(".error-year");
const monthErrorSpan = document.querySelector(".error-month");
const dayErrorSpan = document.querySelector(".error-day");

const submitArrow = document.querySelector(".submit-btn");

submitArrow.onclick = function() {
    const day = dayInput.value;
    const month = monthInput.value;
    const year = yearInput.value;


    //mm-dd-yyyy
    const dobString = month + "/" + day + "/" + year;
    const dob = new Date(dobString);
    const currentDate = new Date();
    const milliseconds = currentDate.getTime() - dob.getTime();

    const yearDiff = new Date(milliseconds).getFullYear() - 1970;
    const monthDiff = new Date(milliseconds).getMonth();
    const dayDiff = new Date(milliseconds).getDate();

    yearSpan.innerHTML = yearDiff;
    monthSpan.innerHTML = monthDiff;
    daySpan.innerHTML = dayDiff;
    
   
}

yearInput.onkeyup = function(){
    const currentYear = new Date().getFullYear();

    if(yearInput.value > currentYear) {
        yearErrorSpan.innerHTML = "Provide a year less than current year";
    } else {
        yearErrorSpan.innerHTML = "";
    }
}

monthInput.onkeyup = function(){
    const currentMonth = new Date().getMonth() + 1;
    const currentYear = new Date().getFullYear();


    if ( (monthInput.value > currentMonth) && (yearInput.value >= currentYear) ) {
        monthErrorSpan.innerHTML = "Provide a month less than current month";
    } else if( (monthInput.value > 12)){
         monthErrorSpan.innerHTML = "Provide a month less than current 12";
    } else{
        monthErrorSpan.innerHTML = "";
    }
}

dayInput.onkeyup = function(){
    const currentDay = new Date().getDate();
    const currentMonth = new Date().getMonth() + 1;
    const currentYear = new Date().getFullYear();

    
    if ( (dayInput.value > currentDay) && (monthInput.value >= currentMonth) && (yearInput.value >= currentYear) ) {
        dayErrorSpan.innerHTML = "Provide a day less than current day";
    } else if( (dayInput.value > 31)){
         dayErrorSpan.innerHTML = "Provide a day less than current 31";
    } else{
        dayErrorSpan.innerHTML = "";
    }
}